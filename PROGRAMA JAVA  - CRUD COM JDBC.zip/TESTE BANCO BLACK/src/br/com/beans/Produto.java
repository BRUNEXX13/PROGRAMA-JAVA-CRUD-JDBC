package br.com.beans;

public class Produto {
	
	
	private int codigomercadoria;
	private String categoria;
	private String nomemercadoria;
	
	
	
	public int getCodigomercadoria() {
		return codigomercadoria;
	}
	public void setCodigomercadoria(int codigomercadoria) {
		this.codigomercadoria = codigomercadoria;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getNomemercadoria() {
		return nomemercadoria;
	}
	public void setNomemercadoria(String nomemercadoria) {
		this.nomemercadoria = nomemercadoria;
	}
	
	
	

}
