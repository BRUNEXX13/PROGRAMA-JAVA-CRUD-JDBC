package br.com.beans;

public class Categoria {

	private int codigocategoria;
	private String nomecategoria;
	
	public int getCodigocategoria() {
		return codigocategoria;
	}
	public void setCodigocategoria(int codigocategoria) {
		this.codigocategoria = codigocategoria;
	}
	public String getNomecategoria() {
		return nomecategoria;
	}
	public void setNomecategoria(String nomecategoria) {
		this.nomecategoria = nomecategoria;
	}
	
	
	
	
}
