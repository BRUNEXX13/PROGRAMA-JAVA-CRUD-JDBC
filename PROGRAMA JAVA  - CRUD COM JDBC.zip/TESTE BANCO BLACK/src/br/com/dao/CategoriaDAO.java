package br.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import br.com.beans.Categoria;
import br.com.factory.ConexaoFactory;

public class CategoriaDAO {

	Connection conexao;

	public CategoriaDAO() throws SQLException {
		conexao = new ConexaoFactory().geConnection();

	}

	public String novo(int codigocategoria, String nomecategoria) {
		PreparedStatement st = null;
		String sql = "";
		sql += "INSERT INTO CATEGORIA(cod_categoria, nm_categoria)";
		sql += "VALUES(?,?)"; // VALORES ?? - 
			//Sigificam quantos dados forem pro banco exemplo codigocategoria � um 1 nome categoria � 2 por isso 2 (?,?)

		try {

			st = conexao.prepareStatement(sql);
			st.setInt(1, codigocategoria);
			st.setString(2, nomecategoria);
			st.executeUpdate();
			return "Categoria Inserida com Sucesso";
			
		} catch (Exception e) {
			return " Erro ao Inserir Categoria";
		}

	}
	

	public String alterar(int codigocategoria, String nomecategoria) {
		PreparedStatement st = null;
		String sql = "UPDATE CATEGORIA SET nm_categoria=? WHERE cod_categoria=?";
		                                    // nomes que estao na tabela do seu banco
		try {
			st = conexao.prepareStatement(sql);
			st.setString(1, nomecategoria);    // st = Prepared Statment =  | Preparando Recebimento no Banco
			st.setInt(2, codigocategoria); // CHAMAR OS NOMES DAS VARIAVEIS //
			st.executeUpdate(); //FAZ O UPDATE NO BANCO ALTERANDO //
			return " Categoria Alterada com Sucesso";
		} catch (Exception e) {
			return "Erro ao alterar Categoria";
		}

	}

	public String excluir(int codigocategoria) {
		PreparedStatement st = null;
		String sql = "DELETE FROM CATEGORIA WHERE cod_categoria=?";
		                                   // nomes que estao na tabela do seu banco | exemplo no meu cod_categoria
		try {
			st = conexao.prepareStatement(sql);
			st.setInt(1, codigocategoria);
			st.executeUpdate();  // FAZ O UPDATE NO BANCO //
			return "Categoria Excluida com Sucesso";
		} catch (Exception e) {
			return "Erro ao excluir Categoria";
		}

	}
		// MAP Recebendo INTEGER // LEMBRANDO HASHMAP RECEBE STRINGS, INTEGER ..
	   public Map<Integer, Categoria> listar() {
		PreparedStatement st = null;
		ResultSet rs = null;
        
		// CRIANDO HASHMAP < INTEGER, CATEGORIA >
		
		Map<Integer, Categoria> categorias = new HashMap<Integer, Categoria>();

		         // SELECIONANDO NO BANCO //
		String sql = "SELECT * FROM CATEGORIA"; // Tabela CRIADA NO BANCO CATEGORIA
		try {
			st = conexao.prepareStatement(sql);
			rs = st.executeQuery();   // EXECUTA A LISTA PRA LISTAGEM
			
			while (rs.next()) {
				Categoria c = new Categoria();
				c.setCodigocategoria(rs.getInt("cod_categoria")); // hashmap usar os nomes que estao estao no banco
				c.setNomecategoria(rs.getString("nm_categoria"));
				categorias.put(c.getCodigocategoria(), c);
			}

			return categorias;

		} catch (SQLException e) {
			System.out.println("Erro ao Listar Categorias");
			return null;
		}

	}
}
