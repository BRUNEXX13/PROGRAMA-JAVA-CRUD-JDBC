package br.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import br.com.beans.Categoria;
import br.com.beans.Produto;
import br.com.factory.ConexaoFactory;

public class ProdutoDAO {
	Connection conexao;

	public ProdutoDAO() throws SQLException {
		conexao = new ConexaoFactory().geConnection();

	}

	public String novo(int codigomercadoria, String categoria, String nomecategoria) {
		PreparedStatement st = null;
		String sql = "";
		sql += "INSERT INTO PRODUTO (cod_mercadoria, cat_categoria, nm_mercadoria)";
		sql += "VALUES(?,?,?)";
		try {

			st = conexao.prepareStatement(sql);
			st.setInt(1, codigomercadoria);
			st.setString(2,categoria);
			st.setString(3, nomecategoria);
			st.executeUpdate();
			return "Mercadoria  Inserida com Sucesso";
		} catch (Exception e) {
			return " Erro ao Inserir Categoria";
		}

	}

	public String alterar(int codigocategoria, String nomecategoria) {
		PreparedStatement st = null;
		String sql = "UPDATE CATEGORIA SET nm_categoria=? WHERE cod_categoria=?";
		                                    // nomes que estao na tabela do seu banco
		try {
			st = conexao.prepareStatement(sql);
			st.setString(1, nomecategoria);    // st = Prepared Statment =  | Preparando Recebimento no Banco
			st.setInt(2, codigocategoria); // CHAMAR OS NOMES DAS VARIAVEIS //
			st.executeUpdate(); //FAZ O UPDATE NO BANCO ALTERANDO //
			return " Categoria Alterada com Sucesso";
		} catch (Exception e) {
			return "Erro ao alterar Categoria";
		}

	}
	
	
	public String alterar(int codigomercardoria, String categoria, String nomemercadoria) {
		PreparedStatement st = null;
		String sql = "UPDATE PRODUTO  SET cat_categoria=? AND  nm_mercadoria=?  WHERE cod_mercadoria=?"; 
		try {
			st = conexao.prepareStatement(sql);
			st.setString(1, categoria);
			st.setString(2,nomemercadoria);
			st.setInt(3, codigomercardoria);
			st.executeUpdate();
			return " Mercadoria  Alterada com Sucesso";
		} catch (Exception e) {
			return "Erro ao alterar Categoria";
		}

	}

	public Map<Integer, Produto> listar() {

		PreparedStatement st = null;
		ResultSet rs = null;

		// CRIANDO HASHMAP < INTEGER, CATEGORIA >

		Map<Integer, Produto> produtos = new HashMap<Integer, Produto>();

		// SELECIONANDO NO BANCO //
		String sql = "SELECT * FROM PRODUTO "; // Tabela CRIADA NO
															// BANCO CATEGORIA
		try {
			st = conexao.prepareStatement(sql);
			rs = st.executeQuery(); // Prepara o ResultSET

			
			// Result Set = rs
			while (rs.next()) {
				Produto p = new Produto();
				p.setCodigomercadoria(rs.getInt("cod_mercadoria"));
				p.setCategoria(rs.getString("cat_categoria"));
				p.setNomemercadoria(rs.getString("nm_mercadoria"));
				produtos.put(p.getCodigomercadoria(), p);

			}

			return produtos;

		} catch (SQLException e) {
			System.out.println("Erro ao Listar Produtos");
			return null;
		}

	}

	public String excluir(int codigomercadoria) {
		PreparedStatement st = null;
		String sql = "DELETE FROM PRODUTO WHERE cod_mercadoria=?";
		try {
			st = conexao.prepareStatement(sql);
			st.setInt(1, codigomercadoria);
			st.executeUpdate();
			return "Mercadoria Excluida com sucesso";
		} catch (SQLException e) {
			return "Erro ao Excluir Mercadoria";
		}

	}

	
	

}
