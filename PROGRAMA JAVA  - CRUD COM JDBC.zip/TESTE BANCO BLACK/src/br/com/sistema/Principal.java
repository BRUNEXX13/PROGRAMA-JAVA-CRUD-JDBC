package br.com.sistema;

import java.io.IOException;
import java.sql.SQLException;


public class Principal {
	public static void main(String[] args) throws IOException, InterruptedException{
		Menu m;
		try {
			m = new Menu();
			m.inicio();
		} catch (SQLException e) {
			System.out.println("Nao foi possicel conectar:"+e.getMessage());
		}
		
	}
}
