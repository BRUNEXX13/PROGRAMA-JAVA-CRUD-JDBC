package br.com.sistema;

import java.sql.SQLException;
import java.util.Scanner;

import br.com.beans.Categoria;
import br.com.beans.Produto;
import br.com.bo.CategoriaBO;
import br.com.bo.ProdutoBO;
import br.com.dao.ProdutoDAO;

public class Menu {

	private CategoriaBO categoriabo;
	private ProdutoBO produtobo;

	public Menu() throws SQLException {
		categoriabo = new CategoriaBO();
		produtobo = new ProdutoBO();

	}

	public void inicio() {
		Scanner sc = new Scanner(System.in);
		int opcao;
		do {

			limpatela();
			System.out.println("---------------------------");
			System.out.println("---  MENU PRINCIPAL -----  ");
			System.out.println("------------------------   ");
			System.out.println("1 - Cadastrar Categoria -  ");
			System.out.println("2 - Alterar   Categoria -  ");
			System.out.println("3 - Listar Categorias -    ");
			System.out.println("4 - Excluir Categoria ---  ");
			System.out.println("--------------------------- ");
			System.out.println("5 - Cadastrar Mercadorias - ");
			System.out.println("6 - Alterar   Mercadoria  - ");
			System.out.println("7 - Listar    Mercadorias - ");
			System.out.println("8 - Excluir   Mercadoria  - ");

			System.out.println("9 -  Sair ");

			System.out.println("-------------------------------");
			System.out.println("Digite sua opniao");
			opcao = sc.nextInt();

			switch (opcao) {
			case 1:
				cadastrar();
				break;
			case 2:
				alterar();
				break;
			case 3:
				listar();
				break;
			case 4:
				excluir();
				break;
			case 5:
				cadastrarmercadoria();
				break;
			case 6:
				alterarmercadoria();
				break;
			case 7:
				listarmercadoria();
				break;
			case 8:
				excluirmercadoria();
				break;
			case 9:
				sair();
				break;
			default:
				erro("Opcao invalida");
			}
		} while (opcao != 9);
	}

	private void excluirmercadoria() {
		
		Scanner sc = new Scanner(System.in);

		int codigomercadoria;

		limpatela();
		System.out.println("--------------");
		System.out.println("Excluir Categoria");
		System.out.println("---------------");

		System.out.println("Digite o Codigo da Categoria");
		codigomercadoria= sc.nextInt();
		sc.nextLine();

		System.out.println(produtobo.excluir(codigomercadoria));
		System.out.println("Pressione Enter para continuar");
		sc.nextLine();
	
	}

	private void listarmercadoria() {
		
		
		Scanner sc = new Scanner(System.in);
		limpatela();
		System.out.println("----------------");
		System.out.println("Listar Produtos");
		System.out.println("-------------------");

		for (Produto p : produtobo.listar().values()) {

			System.out.println("C�digo da Mercadoria: " +  p.getCodigomercadoria());
			System.out.println("Nome da Categoria: " +     p.getCategoria());
			System.out.println("Nome da Mercadoria: " +    p.getNomemercadoria());
			System.out.println("--------------------------");

		}

		System.out.println("Pressione ENTER para continuar");
		sc.nextLine();

	}
	
	private void alterarmercadoria() {

		Scanner sc = new Scanner(System.in);

		int codigomercadoria;
		String categoria;
		String nomemercadoria;

		limpatela();

		System.out.println("-----------");
		System.out.println(" Alterar Mercadoria");

		System.out.println("Digite o codigo da Categoria");
		codigomercadoria = sc.nextInt();
		sc.nextLine();

		System.out.println("Digite a nova Categoria");
		categoria = sc.nextLine();

		System.out.println("Digite o novo nome  da Mercadoria");
		nomemercadoria = sc.nextLine();

		System.out.println(produtobo.alter(codigomercadoria, categoria, nomemercadoria));
		System.out.println("Presione Enter para Continuar");
		sc.nextLine();

	}

	private void cadastrarmercadoria() {

		Scanner sc = new Scanner(System.in);

		int codigomercadoria;
		String categoria;
		String nomemercadoria;

		limpatela();
		System.out.println("------------");
		System.out.println("Cadastrar Nova Mercadoria");
		System.out.println("------------------");

		System.out.println("Digite o Codigo");
		codigomercadoria = sc.nextInt();
		sc.nextLine();

		System.out.println("Digite a categoria da  Mercadoria");
		categoria = sc.nextLine();

		System.out.println("Digite o nome da Mercadoria");
		nomemercadoria = sc.nextLine();

		System.out.println("Pressione ENTER para Continuar");
		sc.nextLine();

		System.out.println(produtobo.novo(codigomercadoria, categoria, nomemercadoria));
		System.out.println("Pressione ENTER para continuar");
		sc.nextLine();

	}

	public void cadastrar() {
		Scanner sc = new Scanner(System.in);

		int codigocategoria;
		String nomecategoria;

		limpatela();
		System.out.println("------------");
		System.out.println("Cadastrar Nova Categoria");
		System.out.println("------------------");

		System.out.println("Digite o Codigo");
		codigocategoria = sc.nextInt();
		sc.nextLine();

		System.out.println("Digite o nome da Categoria");
		nomecategoria = sc.nextLine();

		System.out.println("Pressione ENTER para Continuar");
		sc.nextLine();

		System.out.println(categoriabo.novo(codigocategoria, nomecategoria));
		System.out.println("Pressione ENTER para continuar");
		sc.nextLine();

	}

	public void alterar() {
		Scanner sc = new Scanner(System.in);

		int codigocategoria;
		String nomecategoria;

		limpatela();

		System.out.println("-----------");
		System.out.println(" Alterar Categoria");

		System.out.println("Digite o codigo da Categoria");
		codigocategoria = sc.nextInt();
		sc.nextLine();

		System.out.println("Digite o novo nome  da Categoria");
		nomecategoria = sc.nextLine();

		System.out.println(categoriabo.alterar(codigocategoria, nomecategoria));
		System.out.println("Presione Enter para Continuar");
		sc.nextLine();

	}

	public void listar() {
		Scanner sc = new Scanner(System.in);
		limpatela();
		System.out.println("----------------");
		System.out.println("Listar Categorias");
		System.out.println("-------------------");

		for (Categoria c : categoriabo.listar().values()) {

			System.out.println("C�digo da categoria: " + c.getCodigocategoria());
			System.out.println("Nome da Categoria: " + c.getNomecategoria());
			System.out.println("--------------------------");

		}

		System.out.println("Pressione ENTER para continuar");
		sc.nextLine();

	}

	public void excluir() {
		Scanner sc = new Scanner(System.in);

		int codigocategoria;

		limpatela();
		System.out.println("--------------");
		System.out.println("Excluir Categoria");
		System.out.println("---------------");

		System.out.println("Digite o Codigo da Categoria");
		codigocategoria = sc.nextInt();
		sc.nextLine();

		System.out.println(categoriabo.excluir(codigocategoria));
		System.out.println("Pressione Enter para continuar");
		sc.nextLine();

	}

	public void erro(String mensagem) {
		Scanner sc = new Scanner(System.in);
		limpatela();
		System.out.println("-------------------------------");
		System.out.println(mensagem);
		System.out.println("-------------------------------");
		System.out.println("Pressione ENTER para continuar");
		sc.nextLine();
	}

	public void sair() {
		limpatela();
		System.out.println("Obrigado por usar o sistema");
	}

	public void limpatela() {
		try {
			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		} catch (Exception e) {
			System.out.println("Erro ao limpar a tela");
		}
	}

}
