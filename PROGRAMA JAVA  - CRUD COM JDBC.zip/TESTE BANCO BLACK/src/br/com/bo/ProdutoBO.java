package br.com.bo;

import java.sql.SQLException;
import java.util.Map;

import br.com.beans.Categoria;
import br.com.beans.Produto;
import br.com.dao.ProdutoDAO;

public class ProdutoBO {
	 ProdutoDAO produtodao;

	
	public ProdutoBO() throws SQLException {
		produtodao = new ProdutoDAO();
	}
	
	public String novo(int codigomercardoria, String categoria, String nomemercadoria) {
		return produtodao.novo(codigomercardoria,categoria,nomemercadoria);
	}

	public String alter(int codigomercardoria, String categoria, String nomemercadoria) {
		return produtodao.alterar(codigomercardoria,categoria,nomemercadoria);
	}

	public String excluir(int codigomercadoria) {
		return produtodao.excluir(codigomercadoria);

	}

	public Map<Integer, Produto> listar() {
		return produtodao.listar();
	}

}
