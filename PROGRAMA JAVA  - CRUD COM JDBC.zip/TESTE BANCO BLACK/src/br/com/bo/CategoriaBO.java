package br.com.bo;

import java.sql.SQLException;
import java.util.Map;


import br.com.beans.Categoria;
import br.com.dao.CategoriaDAO;

public class CategoriaBO {
	CategoriaDAO categoriadao;
	
	public CategoriaBO() throws SQLException {
		categoriadao = new CategoriaDAO();
	}

	
	public String novo(Integer codigocategoria, String nomecategoria) {
		return categoriadao.novo(codigocategoria, nomecategoria);
	}

	public String alterar(int codigocategoria, String nomecategoria) {
		return categoriadao.alterar(codigocategoria, nomecategoria);
	}

	public String excluir(int codigocategoria) {
		return categoriadao.excluir(codigocategoria);

	}

	public Map<Integer, Categoria> listar() {
		return categoriadao.listar();
	}

}

	

