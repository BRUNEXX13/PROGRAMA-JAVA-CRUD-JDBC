package br.com.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;




public class ConexaoFactory {

	public Connection geConnection () throws SQLException{
		String url = "jdbc:oracle:thin:/:@localhost:1521:XE";
		String usuario ="OPS$RM75761";
		String senha = "narga10";
		
		return DriverManager.getConnection(url,usuario,senha);
		
	}
	
}
